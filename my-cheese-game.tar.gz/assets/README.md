# Cheese Collector

A Python platform game built with pygame-ce and packaged for browsers with Pygbag.

Use Left and Right to move. Press Up or Space to jump. Collect all eight cheeses.

## Run locally

```sh
python -m pip install pygame-ce pygbag
python -m pygbag .
```

Open http://localhost:8000. To publish, run `python -m pygbag --build .` and upload the contents of `build/web` to the root of a GitHub Pages repository.

The original artwork is in `assets`. The four-pose sprite sheet is loaded directly. Music was not supplied, so this version is silent.
