async def main():
    import pygame
    import random
    import asyncio
    
    pygame.init()
    
    WIDTH = 800
    HEIGHT = 600
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Cheese Collector")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 28)
    
    BACKGROUND = (30, 35, 60)
    BLUE = (70, 105, 170)
    GREEN = (110, 185, 100)
    YELLOW = (255, 210, 50)
    
    try:
        background_picture = pygame.image.load("assets/background.png").convert()
        background_picture = pygame.transform.smoothscale(background_picture, (WIDTH, HEIGHT))
    except pygame.error:
        background_picture = None
    
    # The sheet contains four poses: front, left, back, and right.
    try:
        sprite_sheet = pygame.image.load("assets/cheese_sprite_sheet.png").convert_alpha()
        frame_width = sprite_sheet.get_width() // 4
        frame_height = sprite_sheet.get_height()
    except pygame.error:
        sprite_sheet = None
    
    try:
        cheese_picture = pygame.image.load("assets/cheese_block.png").convert_alpha()
        cheese_picture = pygame.transform.smoothscale(cheese_picture, (38, 30))
    except pygame.error:
        cheese_picture = None
    
    player = pygame.Rect(80, 450, 45, 70)
    player_speed = 5
    player_y_speed = 0
    gravity = 1
    facing = 0
    on_ground = False
    
    platforms = [
        pygame.Rect(0, 550, 800, 50),
        pygame.Rect(80, 430, 220, 20),
        pygame.Rect(380, 340, 220, 20),
        pygame.Rect(560, 460, 150, 20),
    ]
    
    cheese_blocks = []
    for number in range(8):
        x = random.randint(40, 750)
        y = 520 if number < 4 else (400 if number < 6 else 310)
        x = random.randint(90, 265) if number in (4, 5) else (random.randint(390, 565) if number >= 6 else x)
        cheese_blocks.append(pygame.Rect(x, y, 28, 28))
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
    
        keys = pygame.key.get_pressed()
        player_x_speed = 0
    
        if keys[pygame.K_LEFT]:
            player_x_speed = -player_speed
            facing = 1
        if keys[pygame.K_RIGHT]:
            player_x_speed = player_speed
            facing = 3
        if (keys[pygame.K_SPACE] or keys[pygame.K_UP]) and on_ground:
            player_y_speed = -15
    
        player.x += player_x_speed
        if player.left < 0:
            player.left = 0
        if player.right > WIDTH:
            player.right = WIDTH
    
        previous_bottom = player.bottom
        player_y_speed += gravity
        player.y += player_y_speed
        on_ground = False
    
        for platform in platforms:
            if player.colliderect(platform) and player_y_speed >= 0 and previous_bottom <= platform.top:
                player.bottom = platform.top
                player_y_speed = 0
                on_ground = True
    
        for cheese in cheese_blocks[:]:
            if player.colliderect(cheese):
                cheese_blocks.remove(cheese)
    
        if background_picture:
            screen.blit(background_picture, (0, 0))
        else:
            screen.fill(BACKGROUND)
    
        for platform in platforms:
            pygame.draw.rect(screen, BLUE, platform)
            pygame.draw.rect(screen, GREEN, (platform.x, platform.y, platform.width, 6))
    
        for cheese in cheese_blocks:
            if cheese_picture:
                screen.blit(cheese_picture, cheese)
            else:
                pygame.draw.rect(screen, YELLOW, cheese)
                pygame.draw.circle(screen, (215, 150, 25), cheese.center, 5)
    
        if sprite_sheet:
            frame = pygame.Rect(facing * frame_width, 0, frame_width, frame_height)
            picture = sprite_sheet.subsurface(frame)
            picture = pygame.transform.smoothscale(picture, (70, 100))
            screen.blit(picture, player)
        else:
            pygame.draw.rect(screen, (200, 130, 50), player)
    
        screen.blit(font.render("CHEESE COLLECTOR", True, YELLOW), (20, 20))
        screen.blit(font.render("Cheese: " + str(8 - len(cheese_blocks)), True, YELLOW), (20, 55))
    
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)
    
    pygame.quit()
    

import asyncio
asyncio.run(main())

